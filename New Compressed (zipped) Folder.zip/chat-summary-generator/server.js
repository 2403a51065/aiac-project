   // server.js
   require('dotenv').config();
   const express = require('express');
   const cors = require('cors');
   const { OpenAI } = require('openai');

   const app = express();
   const port = process.env.PORT || 3000;

   const openai = new OpenAI({
     apiKey: process.env.OPENAI_API_KEY
   });

   app.use(cors());
   app.use(express.json());
   app.use(express.static('public'));

   app.post('/api/summarize', async (req, res) => {
     try {
       const { text, bulletCount = 5, tone = 'neutral' } = req.body || {};

       if (!text || typeof text !== 'string' || !text.trim()) {
         return res.status(400).json({ error: 'Text is required.' });
       }

       const safeBulletCount = Math.min(Math.max(parseInt(bulletCount, 10) || 5, 3), 20);

       const prompt = `
   You are a professional chat summary assistant.

   Task:
   - Read the following chat or message history.
   - Produce a concise summary as clear bullet points.
   - Use at most ${safeBulletCount} bullet points.
   - Tone should be "${tone}".
   - Only output bullet points, no introduction or conclusion.

   Chat / message history:
   """${text}"""
       `.trim();

       const completion = await openai.chat.completions.create({
         model: 'gpt-4.1-mini',
         messages: [
           { role: 'system', content: 'You are a concise, accurate summarization assistant.' },
           { role: 'user', content: prompt }
         ],
         temperature: 0.4
       });

       const summary = completion.choices[0]?.message?.content?.trim() || '';

       res.json({ summary });
     } catch (error) {
       console.error('Error in /api/summarize:', error);
       res.status(500).json({ error: 'Failed to generate summary. Please try again.' });
     }
   });

   app.listen(port, () => {
     console.log(`Chat Summary Generator running at http://localhost:${port}`);
   });