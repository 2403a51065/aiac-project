   const chatInput = document.getElementById('chat-input');
   const bulletCountInput = document.getElementById('bullet-count');
   const toneSelect = document.getElementById('tone-select');
   const summarizeBtn = document.getElementById('summarize-btn');
   const summaryOutput = document.getElementById('summary-output');
   const statusEl = document.getElementById('status');
   const copyBtn = document.getElementById('copy-btn');

   function setStatus(message, isError = false) {
     statusEl.textContent = message || '';
     statusEl.classList.toggle('status--error', !!isError);
   }

   function setLoading(isLoading) {
     summarizeBtn.disabled = isLoading;
     summarizeBtn.textContent = isLoading ? 'Summarizing…' : 'Summarize';
   }

   async function handleSummarize() {
     const text = chatInput.value.trim();
     const bulletCount = bulletCountInput.value;
     const tone = toneSelect.value;

     if (!text) {
       setStatus('Please paste some chat or message text first.', true);
       return;
     }

     setStatus('Talking to the AI…');
     setLoading(true);
     copyBtn.disabled = true;

     try {
       const response = await fetch('/api/summarize', {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json'
         },
         body: JSON.stringify({ text, bulletCount, tone })
       });

       if (!response.ok) {
         const errorData = await response.json().catch(() => ({}));
         const msg = errorData.error || 'Something went wrong while summarizing.';
         throw new Error(msg);
       }

       const data = await response.json();
       const rawSummary = data.summary || '';

       summaryOutput.innerHTML = '';

       const normalized = rawSummary.replace(/\r\n/g, '\n').trim();
       const lines = normalized.split('\n').filter(Boolean);

       const ul = document.createElement('ul');

       if (lines.length === 1 && !lines[0].startsWith('-')) {
         const li = document.createElement('li');
         li.textContent = lines[0];
         ul.appendChild(li);
       } else {
         for (const line of lines) {
           const cleaned = line.replace(/^[\-\*\d\.\)\s]+/, '').trim();
           if (!cleaned) continue;
           const li = document.createElement('li');
           li.textContent = cleaned;
           ul.appendChild(li);
         }
       }

       if (!ul.children.length) {
         const li = document.createElement('li');
         li.textContent = normalized || 'No summary returned.';
         ul.appendChild(li);
       }

       summaryOutput.appendChild(ul);
       setStatus('Summary ready.');
       copyBtn.disabled = false;
     } catch (error) {
       console.error(error);
       setStatus(error.message || 'Failed to generate summary.', true);
     } finally {
       setLoading(false);
     }
   }

   async function handleCopy() {
     const text = summaryOutput.innerText.trim();
     if (!text) return;
     try {
       await navigator.clipboard.writeText(text);
       setStatus('Summary copied to clipboard.');
     } catch (err) {
       console.error(err);
       setStatus('Could not copy to clipboard.', true);
     }
   }

   summarizeBtn.addEventListener('click', handleSummarize);
   copyBtn.addEventListener('click', handleCopy);

   chatInput.addEventListener('keydown', (e) => {
     if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
       e.preventDefault();
       handleSummarize();
     }
   });